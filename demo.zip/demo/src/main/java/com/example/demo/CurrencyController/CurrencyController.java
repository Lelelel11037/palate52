package com.example.demo.CurrencyController;


import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.HashMap;
import java.util.Map;

@Controller
public class CurrencyController {

    private static final Map<String, Double> exchangeRates = new HashMap<>();

    static {
        exchangeRates.put("USD", 1.0);
        exchangeRates.put("EUR", 0.92);
        exchangeRates.put("RUB", 92.5);
        exchangeRates.put("GBP", 0.79);
    }

    @GetMapping("/converter")
    public String showConverter(Model model) {
        model.addAttribute("currencies", exchangeRates.keySet());
        return "converter";
    }

    @PostMapping("/converter")
    public String convert(
            @RequestParam("amount") double amount,
            @RequestParam("fromCurrency") String fromCurrency,
            @RequestParam("toCurrency") String toCurrency,
            Model model) {

        double result = 0;
        String error = null;

        try {
            double amountInUSD = amount / exchangeRates.get(fromCurrency);
            result = amountInUSD * exchangeRates.get(toCurrency);
            result = Math.round(result * 100.0) / 100.0;
        } catch (Exception e) {
            error = "Ошибка при конвертации валюты";
        }

        model.addAttribute("amount", amount);
        model.addAttribute("fromCurrency", fromCurrency);
        model.addAttribute("toCurrency", toCurrency);
        model.addAttribute("result", error != null ? error : String.valueOf(result));
        model.addAttribute("error", error);
        model.addAttribute("currencies", exchangeRates.keySet());

        return "converter";
    }
}